(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_about_page_tsx_eec68053._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_about_page_tsx_eec68053._.js",
  "chunks": [
    "static/chunks/src_53315aa2._.js",
    "static/chunks/src_components_1dafe789._.css"
  ],
  "source": "dynamic"
});
