(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_clientele_page_tsx_eec68053._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_clientele_page_tsx_eec68053._.js",
  "chunks": [
    "static/chunks/src_components_Clientele_Clientele_a4a621a4.css",
    "static/chunks/src_dee96a33._.js"
  ],
  "source": "dynamic"
});
