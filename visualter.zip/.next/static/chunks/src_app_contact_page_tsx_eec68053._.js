(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_contact_page_tsx_eec68053._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_contact_page_tsx_eec68053._.js",
  "chunks": [
    "static/chunks/src_362a442e._.js",
    "static/chunks/src_components_1dafe789._.css"
  ],
  "source": "dynamic"
});
