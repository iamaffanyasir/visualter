(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_eec68053._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_eec68053._.js",
  "chunks": [
    "static/chunks/src_components_4829196b._.css",
    "static/chunks/src_components_1790ea48._.js"
  ],
  "source": "dynamic"
});
