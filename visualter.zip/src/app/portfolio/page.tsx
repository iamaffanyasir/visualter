export default function Portfolio() {
  const projects = [
    {
      title: "E-Commerce Platform",
      description: "A modern e-commerce solution with advanced features",
      technologies: ["Next.js", "Node.js", "MongoDB"],
      image: "/portfolio/ecommerce.jpg",
    },
    {
      title: "Healthcare Management System",
      description: "Comprehensive healthcare management platform",
      technologies: ["React", "Express", "PostgreSQL"],
      image: "/portfolio/healthcare.jpg",
    },
    {
      title: "Financial Dashboard",
      description: "Real-time financial data visualization dashboard",
      technologies: ["Vue.js", "Python", "Redis"],
      image: "/portfolio/finance.jpg",
    },
  ];

  return (
    <main className="portfolio">
      <section className="portfolio__hero">
        <div className="portfolio__hero-content">
          <h1 className="portfolio__title">Our Portfolio</h1>
          <p className="portfolio__subtitle">
            Showcasing Our Best Work
          </p>
        </div>
      </section>

      <section className="portfolio__projects">
        <div className="portfolio__grid">
          {projects.map((project, index) => (
            <div key={index} className="portfolio__card">
              <div className="portfolio__card-image">
                <img src={project.image} alt={project.title} />
              </div>
              <div className="portfolio__card-content">
                <h3 className="portfolio__card-title">{project.title}</h3>
                <p className="portfolio__card-description">{project.description}</p>
                <div className="portfolio__card-tech">
                  {project.technologies.map((tech, techIndex) => (
                    <span key={techIndex} className="portfolio__tech-tag">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
