'use client';

import './About.css';

export const About = () => {
  return (
    <div className="about">
      <section className="about__hero">
        <div className="about__hero-content">
          <h1 className="about__hero-title">About Visualter</h1>
          <p className="about__hero-description">
            Transforming ideas into exceptional digital experiences
          </p>
        </div>
      </section>

      <section className="about__vision">
        <div className="about__container">
          <div className="about__vision-content">
            <h2 className="about__section-title">Our Vision</h2>
            <p className="about__section-text">
              At Visualter, we envision a world where technology and creativity converge to create meaningful digital solutions that inspire and empower.
            </p>
          </div>
        </div>
      </section>

      <section className="about__values">
        <div className="about__container">
          <h2 className="about__section-title">Our Values</h2>
          <div className="about__values-grid">
            <div className="about__value-card">
              <i className="about__value-icon fas fa-lightbulb"></i>
              <h3 className="about__value-title">Innovation</h3>
              <p className="about__value-text">
                Pushing boundaries and exploring new possibilities in digital technology
              </p>
            </div>
            <div className="about__value-card">
              <i className="about__value-icon fas fa-users"></i>
              <h3 className="about__value-title">Collaboration</h3>
              <p className="about__value-text">
                Working together to achieve exceptional results
              </p>
            </div>
            <div className="about__value-card">
              <i className="about__value-icon fas fa-star"></i>
              <h3 className="about__value-title">Excellence</h3>
              <p className="about__value-text">
                Delivering outstanding quality in everything we do
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="about__team">
        <div className="about__container">
          <h2 className="about__section-title">Our Team</h2>
          <div className="about__team-grid">
            <div className="about__team-member">
              <div className="about__team-image-wrapper">
                <div className="about__team-image"></div>
              </div>
              <h3 className="about__team-name">John Doe</h3>
              <p className="about__team-position">Founder & CEO</p>
              <p className="about__team-bio">
                Visionary leader with over 15 years of experience in digital innovation
              </p>
            </div>
            <div className="about__team-member">
              <div className="about__team-image-wrapper">
                <div className="about__team-image"></div>
              </div>
              <h3 className="about__team-name">Jane Smith</h3>
              <p className="about__team-position">Creative Director</p>
              <p className="about__team-bio">
                Award-winning designer with a passion for creating impactful experiences
              </p>
            </div>
            <div className="about__team-member">
              <div className="about__team-image-wrapper">
                <div className="about__team-image"></div>
              </div>
              <h3 className="about__team-name">Mike Johnson</h3>
              <p className="about__team-position">Technical Lead</p>
              <p className="about__team-bio">
                Expert in cutting-edge technologies and innovative solutions
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="about__journey">
        <div className="about__container">
          <h2 className="about__section-title">Our Journey</h2>
          <div className="about__timeline">
            <div className="about__timeline-item">
              <div className="about__timeline-year">2020</div>
              <div className="about__timeline-content">
                <h3 className="about__timeline-title">Company Founded</h3>
                <p className="about__timeline-text">
                  Visualter was established with a vision to transform digital experiences
                </p>
              </div>
            </div>
            <div className="about__timeline-item">
              <div className="about__timeline-year">2021</div>
              <div className="about__timeline-content">
                <h3 className="about__timeline-title">Global Expansion</h3>
                <p className="about__timeline-text">
                  Expanded our services to international markets
                </p>
              </div>
            </div>
            <div className="about__timeline-item">
              <div className="about__timeline-year">2022</div>
              <div className="about__timeline-content">
                <h3 className="about__timeline-title">Innovation Award</h3>
                <p className="about__timeline-text">
                  Recognized for outstanding contributions to digital innovation
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="about__cta">
        <div className="about__container">
          <div className="about__cta-content">
            <h2 className="about__cta-title">Ready to Work Together?</h2>
            <p className="about__cta-text">
              Let's create something amazing together
            </p>
            <a href="/contact" className="about__cta-button">
              Get in Touch
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
