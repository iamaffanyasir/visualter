'use client';

import './Projects.css';

const projects = [
  {
    title: 'E-Commerce Platform',
    category: 'Web Development',
    image: '/images/projects/ecommerce.jpg'
  },
  {
    title: 'AI Chat Assistant',
    category: 'Machine Learning',
    image: '/images/projects/ai-chat.jpg'
  },
  {
    title: 'Mobile Banking App',
    category: 'UI/UX Design',
    image: '/images/projects/banking.jpg'
  }
];

export const Projects = () => {
  return (
    <section className="projects">
      <div className="projects__container">
        <div className="projects__header">
          <h2 className="projects__title">Featured Projects</h2>
          <p className="projects__subtitle">Showcasing our best work</p>
        </div>

        <div className="projects__grid">
          {projects.map((project, index) => (
            <div key={index} className="projects__card">
              <div className="projects__card-image">
                <img src={project.image} alt={project.title} />
              </div>
              <div className="projects__card-content">
                <span className="projects__card-category">{project.category}</span>
                <h3 className="projects__card-title">{project.title}</h3>
                <button className="projects__card-button">
                  View Project
                  <span className="projects__card-button-icon">→</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
